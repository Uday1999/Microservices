package com.example.addressApp.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.addressApp.model.Address;
import com.example.addressApp.repositary.AddressRepo;
import com.example.addressApp.service.response.AddressResponse;

@Service
public class addressService {

	@Autowired
	private AddressRepo addressrepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	public AddressResponse addressresponse(int employeId) {
	
		Address address = addressrepo.findAddressByEmployeId(employeId);
		AddressResponse addressResponse = modelMapper.map(address, AddressResponse.class);
		
		return addressResponse;
	}
}
