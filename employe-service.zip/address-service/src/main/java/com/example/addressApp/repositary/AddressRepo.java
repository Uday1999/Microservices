package com.example.addressApp.repositary;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.addressApp.model.Address;

public interface AddressRepo extends JpaRepository<Address, Integer> {

	@Query(nativeQuery=true,value="select ea.id,ea.lane1,ea.lane2,ea.state,ea.pin from microserviceemploye.address ea join microserviceemploye.employe e on e.id = ea.employe_id where ea.employe_id=:employeId")
	Address findAddressByEmployeId(@Param("employeId") int employeId);
}
