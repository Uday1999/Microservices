package com.example.employeApp.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.employeApp.Repository.EmployeRepo;
import com.example.employeApp.model.Employe;
import com.example.employeApp.response.AddressResponse;
import com.example.employeApp.response.EmployeResponse;



@Service
public class EmployeService {

	
	@Autowired
	private EmployeRepo employerepo;
	
	@Autowired
	private ModelMapper modelmapper;
	
	private RestTemplate restTemplate;
	
//	@Value("${addressservice.base.url}")
//	private String addressServiceURL;
	
	public EmployeService(@Value("${addressservice.base.url}")String addressServiceURL,RestTemplateBuilder builder) {
		
	//	System.out.println("uri"+addressServiceURL);
		
		this.restTemplate = builder
				           .rootUri(addressServiceURL)
				           .build();
	}
	
	
	public EmployeResponse GetEmployeById(int id) {
		
		//AddressResponse addressresponse = new AddressResponse();
		
		Employe emp = employerepo.findById(id).get();
		EmployeResponse employeresponse = modelmapper.map(emp, EmployeResponse.class);
		
//		EmployeResponse emplyeresponse = new EmployeResponse();
//		emplyeresponse.setId(emp.getId());
//		emplyeresponse.setName(emp.getName());
//		emplyeresponse.setEmail(emp.getEmail());
//		emplyeresponse.setBlood_group(emp.getBlood_group());
		
		AddressResponse addressresponse = restTemplate.getForObject("/address/{id}", AddressResponse.class,id);
		
		employeresponse.setAddressresponse(addressresponse);
		

		return employeresponse;
	}
}
