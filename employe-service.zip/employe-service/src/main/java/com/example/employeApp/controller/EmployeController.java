package com.example.employeApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.employeApp.response.EmployeResponse;
import com.example.employeApp.service.EmployeService;

@RestController
public class EmployeController {

	@Autowired
	private EmployeService employeservice;
	
	@GetMapping("/employe/{id}")
	ResponseEntity<EmployeResponse> getEmpByID(@PathVariable("id") int id) {
		
		EmployeResponse empResponse  = employeservice.GetEmployeById(id);
		return ResponseEntity.status(HttpStatus.OK).body(empResponse);
		
	}
}
