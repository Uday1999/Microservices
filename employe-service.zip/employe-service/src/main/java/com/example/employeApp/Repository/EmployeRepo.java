package com.example.employeApp.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.employeApp.model.Employe;

public interface EmployeRepo extends JpaRepository<Employe, Integer> {

}
