package com.example.employeApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
